package com.civil.acarrera.semanados;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ConfirmarDatos extends AppCompatActivity {

    private String nombre;
    private String telefono;
    private String email;
    private String descripcion;
    private int diaDeNacimiento;
    private int mesDeNacimiento;
    private int añoDeNacimiento;
    private TextView tvNombreCompleto;
    private TextView tvTelefono;
    private TextView tvEmail;
    private TextView tvDescripcion;
    private TextView tvFechaDeNacimiento;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);

        Bundle parametros = getIntent().getExtras();

        nombre = parametros.getString(getResources().getString(R.string.nombre));
        telefono = parametros.getString(getResources().getString(R.string.telefono));
        email = parametros.getString(getResources().getString(R.string.email));
        descripcion = parametros.getString(getResources().getString(R.string.descripcionContacto));
        diaDeNacimiento = parametros.getInt(getResources().getString(R.string.dia));
        mesDeNacimiento = parametros.getInt(getResources().getString(R.string.mes)) + 1;
        añoDeNacimiento = parametros.getInt(getResources().getString(R.string.año));

        tvNombreCompleto    = (TextView) findViewById(R.id.tvNombreCompleto);
        tvTelefono          = (TextView) findViewById(R.id.tvTelefono);
        tvEmail             = (TextView) findViewById(R.id.tvEmail);
        tvDescripcion       = (TextView) findViewById(R.id.tvDescripcion);
        tvFechaDeNacimiento = (TextView) findViewById(R.id.tvFechaDeNacimiento);

        tvNombreCompleto.setText(nombre);
        tvTelefono.setText(telefono);
        tvEmail.setText(email);
        tvDescripcion.setText(descripcion);
        String fechaDeNacimiento = diaDeNacimiento + "/" + mesDeNacimiento + "/" + añoDeNacimiento;
        tvFechaDeNacimiento.setText(fechaDeNacimiento);
    }

    public void llamarMainActivity(View view) {
        tvNombreCompleto = (TextView) findViewById(R.id.tvNombreCompleto);
        tvTelefono = (TextView) findViewById(R.id.tvTelefono);
        tvEmail = (TextView) findViewById(R.id.tvEmail);
        tvDescripcion = (TextView) findViewById(R.id.tvDescripcion);

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(getResources().getString(R.string.nombre), nombre);
        intent.putExtra(getResources().getString(R.string.telefono), telefono);
        intent.putExtra(getResources().getString(R.string.email), email);
        intent.putExtra(getResources().getString(R.string.descripcionContacto), descripcion);
        intent.putExtra(getResources().getString(R.string.dia), diaDeNacimiento);
        intent.putExtra(getResources().getString(R.string.mes), mesDeNacimiento - 1);
        intent.putExtra(getResources().getString(R.string.año), añoDeNacimiento);

        startActivity(intent);
        finish();
    }
}
