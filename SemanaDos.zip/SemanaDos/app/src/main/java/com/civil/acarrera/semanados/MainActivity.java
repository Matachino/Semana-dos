package com.civil.acarrera.semanados;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText etNombre;
    private EditText etTelefono;
    private EditText etEmail;
    private EditText etDescripcionContacto;
    private DatePicker dpFechaDeNacimiento;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getIntent().getExtras() != null) {

            Bundle parametros = getIntent().getExtras();

            String nombre = parametros.getString(getResources().getString(R.string.nombre));
            String telefono = parametros.getString(getResources().getString(R.string.telefono));
            String email = parametros.getString(getResources().getString(R.string.email));
            String descripcion = parametros.getString(getResources().getString(R.string.descripcionContacto));
            int diaDeNacimiento = parametros.getInt(getResources().getString(R.string.dia));
            int mesDeNacimiento = parametros.getInt(getResources().getString(R.string.mes));
            int añoDeNacimiento = parametros.getInt(getResources().getString(R.string.año));

            etNombre = (EditText) findViewById(R.id.etNombre);
            etTelefono = (EditText) findViewById(R.id.etTelefono);
            etEmail = (EditText) findViewById(R.id.etEmail);
            etDescripcionContacto = (EditText) findViewById(R.id.etDescripcionContacto);
            dpFechaDeNacimiento  = (DatePicker) findViewById(R.id.dpFechaDeNacimiento);

            etNombre.setText(nombre);
            etTelefono.setText(telefono);
            etEmail.setText(email);
            etDescripcionContacto.setText(descripcion);
            dpFechaDeNacimiento.updateDate(añoDeNacimiento,mesDeNacimiento,diaDeNacimiento);
        }
    }

    public void llamarConfirmarDatos(View view){
        etNombre              = (EditText) findViewById(R.id.etNombre);
        etTelefono            = (EditText) findViewById(R.id.etTelefono);
        etEmail               = (EditText) findViewById(R.id.etEmail);
        etDescripcionContacto = (EditText) findViewById(R.id.etDescripcionContacto);
        dpFechaDeNacimiento = (DatePicker) findViewById(R.id.dpFechaDeNacimiento);

        Intent intent = new Intent(this,ConfirmarDatos.class);
        intent.putExtra(getResources().getString(R.string.nombre),etNombre.getText().toString());
        intent.putExtra(getResources().getString(R.string.telefono), etTelefono.getText().toString());
        intent.putExtra(getResources().getString(R.string.email), etEmail.getText().toString());
        intent.putExtra(getResources().getString(R.string.descripcionContacto), etDescripcionContacto.getText().toString());

        int dia = dpFechaDeNacimiento.getDayOfMonth();
        int mes = dpFechaDeNacimiento.getMonth();
        int año = dpFechaDeNacimiento.getYear();

        intent.putExtra(getResources().getString(R.string.dia),dia);
        intent.putExtra(getResources().getString(R.string.mes),mes);
        intent.putExtra(getResources().getString(R.string.año),año);

        startActivity(intent);
        finish();
    }

}
